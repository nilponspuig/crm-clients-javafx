# CRM de Clients (JavaFX)
Projecte base per a UF2 de Desenvolupament d'Interfícies.
Inclou estructura NetBeans, suport per JavaFX i persistència via JSON.
